Tony logo animatic: prism turn (version A2)
==========================================

VIDEO
  video/tony-logo-prism-4k-3840x2160.mp4   6.0s, 30fps, H.264 + AAC. Rendered natively at 4K (not upscaled).
  video/tony-logo-prism-1080p-1920x1080.mp4 Same animation rendered natively at 1080p.
  video/final-frame-4k.png                  Last frame (The JP Collective), 4K still.

  Both are real renders of the same HTML animation at different pixel sizes; neither is
  a scaled copy of the other. The Vistage and JP Collective logos are sharp at 4K.
  The BSGI logo's only available source is a 600px-wide PNG, so it is stretched about 2x
  inside the 4K frame and looks slightly soft up close. A vector/high-res BSGI logo
  from BSGI would fix that; drop it into project/assets/bsgi.png and re-render.

TIMING (St. Lucia, "Elevate", from 0:00, 103.4 BPM, one bar = 2.32s)
  0.19s  Bar 1 downbeat  Vistage appears
  2.51s  Bar 2 downbeat  Prism turns end-over-end to BSGI
  4.83s  Bar 3 downbeat  Prism turns to The JP Collective
  4.9-6.0s               Hold, music fades out

LOGOS
  logos/original-downloads/  Files exactly as pulled from each company's website:
    vistage-wordmark.svg      vistage.com header wordmark (vector)
    logo-vistage-2025.png     vistage.com 1200x1200 PNG
    berkshire-systems-logo.png  bsgi.com masthead logo, 600x178 (largest they serve)
    logo-berkshire-mark.png   bsgi.com "B" mark only
    JPC_LOGOTYPE_Navy.png     thejpcollective.com header logotype, 2029x204
    JPC_LOGO_nonbleed_Navy.png / _ApOr.png  JP Collective square marks
  logos/as-used/             The three files in the video. vistage.svg is the site
                             wordmark recolored to Vistage navy #003E5E.

MUSIC
  music/elevate-first-6s-with-fade.mp3  The first 6s of the track with a 1.1s fade-out,
  exactly as used. Pulled from the official YouTube video
  (https://www.youtube.com/watch?v=N8aM18_G76Q), so for anything public, use a
  licensed copy of the song.

PROJECT
  project/  HyperFrames source (HTML + GSAP). To re-render:
    cd project && npx hyperframes@0.8.166 render --resolution 4k -o out-4k.mp4
